# plugin.video.p2psport

Modifications over the version 0.1.4 version of the discontinued kodi addon by natko1412 and Extracsaba.

This addon will be also discontinued, use the great Castaway addon from natko1412.

Find it in the forums of tvaddons.ag
